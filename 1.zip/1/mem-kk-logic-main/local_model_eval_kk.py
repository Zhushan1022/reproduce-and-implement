#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Xie et al. (2024) Knights and Knaves - 本地模型版本

使用本地LLM模型在Knights and Knaves逻辑谜题上进行记忆化vs推理能力评估
"""

import sys
import os
sys.path.append('../../')

from local_llm_interface import load_model, SUPPORTED_MODELS
from utils import load_jsonl, write_jsonl
import json
import time
import re
from typing import Dict, List, Tuple
import numpy as np

class LocalKKEvaluator:
    """Knights and Knaves本地模型评估器"""
    
    def __init__(self, model_key: str = "qwen-0.5b"):
        """初始化评估器"""
        self.model_key = model_key
        self.llm = None
        
    def load_model(self):
        """加载模型"""
        if self.llm is None:
            print(f"🔥 Loading model: {self.model_key}")
            self.llm = load_model(self.model_key)
    
    def cleanup_model(self):
        """清理模型"""
        if self.llm is not None:
            self.llm.cleanup()
            self.llm = None
    
    def gen_test_prompt(self, ntrain: int, test_records: List, test_idx: int) -> Tuple[str, str]:
        """生成测试提示"""
        test_record = test_records[test_idx]
        
        # 构造基础提示
        base_prompt = ""
        
        # 添加few-shot示例（如果需要）
        if ntrain > 0:
            # 从训练数据中选择示例
            train_indices = list(range(len(test_records)))
            train_indices.remove(test_idx)
            selected_indices = train_indices[:ntrain]
            
            for idx in selected_indices:
                example = test_records[idx]
                base_prompt += f"Problem: {example['quiz']}\n"
                base_prompt += f"Answer: {example['solution_text_format']}\n\n"
        
        # 添加测试问题
        prompt = base_prompt + f"Problem: {test_record['quiz']}\n"
        prompt += "Please solve this step by step and identify who is a knight and who is a knave.\n\nAnswer:"
        
        # 标准答案
        label = test_record['solution_text_format']
        
        return prompt, label
    
    def parse_cot_eval(self, response: str, label: str) -> Tuple[bool, str, str]:
        """解析chain-of-thought评估结果"""
        # 简化的解析逻辑
        response = response.strip()
        label = label.strip()
        
        # 提取模型的预测
        prediction = self.extract_prediction(response)
        
        # 格式化标准答案
        formatted_label = self.format_answer(label)
        
        # 比较结果
        is_correct = self.compare_answers(prediction, formatted_label)
        
        return is_correct, prediction, formatted_label
    
    def extract_prediction(self, response: str) -> str:
        """从模型回答中提取预测结果"""
        # 查找典型的答案模式
        patterns = [
            r'\(1\)\s*(.+?)\s*(?:is a|is an)\s*(knight|knave)',
            r'\(2\)\s*(.+?)\s*(?:is a|is an)\s*(knight|knave)',
            r'(\w+)\s*(?:is a|is an)\s*(knight|knave)',
        ]
        
        predictions = []
        lines = response.split('\n')
        
        for line in lines:
            line = line.strip()
            for pattern in patterns:
                matches = re.findall(pattern, line, re.IGNORECASE)
                for match in matches:
                    if len(match) == 2:
                        name, role = match
                        predictions.append(f"{name.strip()} is a {role.lower()}")
        
        # 如果没有找到结构化答案，尝试简单模式
        if not predictions:
            for line in lines:
                if 'knight' in line.lower() and 'knave' in line.lower():
                    predictions.append(line.strip())
                    break
        
        return '\n'.join(predictions) if predictions else response
    
    def format_answer(self, label: str) -> str:
        """格式化标准答案"""
        return label.strip()
    
    def compare_answers(self, prediction: str, label: str) -> bool:
        """比较预测和标准答案"""
        # 简化的比较逻辑
        pred_lower = prediction.lower()
        label_lower = label.lower()
        
        # 提取人名和角色
        pred_pairs = self.extract_name_role_pairs(pred_lower)
        label_pairs = self.extract_name_role_pairs(label_lower)
        
        if len(pred_pairs) == len(label_pairs):
            # 检查每个人的角色是否正确
            correct_count = 0
            for name, role in label_pairs:
                if (name, role) in pred_pairs:
                    correct_count += 1
            return correct_count == len(label_pairs)
        
        return False
    
    def extract_name_role_pairs(self, text: str) -> List[Tuple[str, str]]:
        """提取姓名-角色对"""
        pairs = []
        
        # 常见的姓名
        common_names = ['alice', 'bob', 'charlie', 'david', 'eve', 'frank', 'grace', 'henry',
                       'ivy', 'jack', 'kate', 'liam', 'mary', 'noah', 'olivia', 'peter',
                       'quinn', 'rachel', 'steve', 'tina', 'uma', 'victor', 'wendy', 'xavier',
                       'yara', 'zack', 'zoey', 'oliver', 'william', 'evelyn', 'sebastian',
                       'aria', 'benjamin', 'chloe', 'emma', 'ethan', 'jacob', 'sophia',
                       'daniel', 'mia', 'james', 'harper', 'aiden', 'lily', 'lucas', 'ava',
                       'mason', 'isabella', 'logan', 'amelia', 'alexander', 'charlotte']
        
        for name in common_names:
            if name in text:
                if f'{name}' in text and 'knight' in text:
                    if f'{name}' in text and 'knave' not in text.split(name)[1].split('knight')[0]:
                        pairs.append((name, 'knight'))
                elif f'{name}' in text and 'knave' in text:
                    if f'{name}' in text and 'knight' not in text.split(name)[1].split('knave')[0]:
                        pairs.append((name, 'knave'))
        
        return pairs
    
    def evaluate_subject(self, subject: str, ntrain: int = 0, limit: int = None) -> Dict:
        """评估单个主题"""
        print(f"\n🧩 评估主题: {subject}")
        print("-" * 50)
        
        # 加载数据
        data_path = f"data/test/clean/{subject}.jsonl"
        if not os.path.exists(data_path):
            print(f"❌ 数据文件不存在: {data_path}")
            return {"accuracy": 0.0, "correct": 0, "total": 0, "error": "Data file not found"}
        
        test_records = load_jsonl(data_path)
        
        if limit:
            test_records = test_records[:limit]
        
        print(f"📊 测试样本数: {len(test_records)}")
        
        # 确保模型已加载
        self.load_model()
        
        # 评估
        correct = 0
        total = len(test_records)
        results = []
        
        start_time = time.time()
        
        for i, record in enumerate(test_records):
            try:
                # 生成提示
                prompt, label = self.gen_test_prompt(ntrain, test_records, i)
                
                # 生成回答
                response = self.llm.query(prompt, max_new_tokens=300, temperature=0.1)
                
                # 评估结果
                is_correct, prediction, formatted_label = self.parse_cot_eval(response, label)
                
                if is_correct:
                    correct += 1
                
                # 记录结果
                result = {
                    'quiz': record['quiz'],
                    'names': record['names'],
                    'solution': record['solution'],
                    'solution_text': record['solution_text'],
                    'solution_text_format': record['solution_text_format'],
                    'index': i,
                    'predicts': prediction,
                    'labels': formatted_label,
                    'correct': is_correct,
                    'response': response,
                    'prompts': prompt,
                }
                results.append(result)
                
                # 显示进度
                if (i + 1) % 5 == 0:
                    current_acc = correct / (i + 1)
                    print(f"进度: {i+1}/{total}, 当前准确率: {current_acc:.2%}")
                
            except Exception as e:
                print(f"问题 {i+1} 处理失败: {e}")
                results.append({
                    'quiz': record.get('quiz', ''),
                    'names': record.get('names', []),
                    'solution': record.get('solution', []),
                    'solution_text': record.get('solution_text', ''),
                    'solution_text_format': record.get('solution_text_format', ''),
                    'index': i,
                    'predicts': f"ERROR: {str(e)}",
                    'labels': record.get('solution_text_format', ''),
                    'correct': False,
                    'response': f"ERROR: {str(e)}",
                    'prompts': '',
                })
        
        # 计算最终结果
        accuracy = correct / total if total > 0 else 0.0
        eval_time = time.time() - start_time
        
        result_summary = {
            "subject": subject,
            "model": self.model_key,
            "accuracy": accuracy,
            "correct": correct,
            "total": total,
            "evaluation_time": eval_time,
            "detailed_results": results
        }
        
        print(f"\n📊 结果: {correct}/{total} = {accuracy:.2%}")
        print(f"⏱️  用时: {eval_time:.1f}秒")
        
        return result_summary
    
    def compare_perturbations(self, base_subject: str = "people2_num100", 
                            perturbation_types: List[str] = None,
                            limit: int = 20) -> Dict:
        """比较不同扰动类型的效果"""
        if perturbation_types is None:
            perturbation_types = ["clean", "perturbed_statement", "perturbed_leaf", 
                                "flip_role", "uncommon_name"]
        
        print("🎯 Knights and Knaves扰动评估实验")
        print("="*60)
        print("目标：比较模型在不同扰动版本上的表现，检测记忆化vs推理能力")
        print()
        
        results = {}
        
        for perturb_type in perturbation_types:
            try:
                data_path = f"data/test/{perturb_type}/{base_subject}.jsonl"
                if os.path.exists(data_path):
                    print(f"\n📋 评估扰动类型: {perturb_type}")
                    
                    # 临时修改数据路径进行评估
                    original_subject = base_subject
                    modified_subject = f"../test/{perturb_type}/{base_subject}"
                    
                    result = self.evaluate_subject_by_path(data_path, perturb_type, limit)
                    results[perturb_type] = result
                else:
                    print(f"❌ 扰动类型 {perturb_type} 的数据不存在: {data_path}")
                    results[perturb_type] = {"error": "Data not found"}
                    
            except Exception as e:
                print(f"❌ 扰动类型 {perturb_type} 评估失败: {e}")
                results[perturb_type] = {"error": str(e)}
        
        # 分析结果
        self.analyze_perturbation_results(results)
        
        # 保存结果
        save_path = f"kk_perturbation_results_{self.model_key}.json"
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"\n💾 结果已保存到: {save_path}")
        
        return results
    
    def evaluate_subject_by_path(self, data_path: str, perturb_type: str, limit: int) -> Dict:
        """通过数据路径评估"""
        test_records = load_jsonl(data_path)
        
        if limit:
            test_records = test_records[:limit]
        
        self.load_model()
        
        correct = 0
        total = len(test_records)
        results = []
        
        for i, record in enumerate(test_records):
            try:
                prompt, label = self.gen_test_prompt(0, test_records, i)
                response = self.llm.query(prompt, max_new_tokens=300, temperature=0.1)
                is_correct, prediction, formatted_label = self.parse_cot_eval(response, label)
                
                if is_correct:
                    correct += 1
                
                results.append({
                    'quiz': record['quiz'],
                    'correct': is_correct,
                    'response': response
                })
                
            except Exception as e:
                results.append({
                    'quiz': record.get('quiz', ''),
                    'correct': False,
                    'response': f"ERROR: {str(e)}"
                })
        
        accuracy = correct / total if total > 0 else 0.0
        
        return {
            "perturbation_type": perturb_type,
            "model": self.model_key,
            "accuracy": accuracy,
            "correct": correct,
            "total": total,
            "detailed_results": results
        }
    
    def analyze_perturbation_results(self, results: Dict):
        """分析扰动结果"""
        print("\n📈 扰动分析结果")
        print("-" * 40)
        
        # 提取准确率
        accuracies = {}
        for perturb_type, result in results.items():
            if "accuracy" in result:
                accuracies[perturb_type] = result["accuracy"]
        
        if "clean" in accuracies:
            baseline_acc = accuracies["clean"]
            print(f"Baseline (Clean): {baseline_acc:.2%}")
            
            for perturb_type, acc in accuracies.items():
                if perturb_type != "clean":
                    if baseline_acc > 0:
                        drop = (baseline_acc - acc) / baseline_acc
                        print(f"{perturb_type}: {acc:.2%} (下降 {drop:.1%})")
                    else:
                        print(f"{perturb_type}: {acc:.2%}")
            
            # 记忆化分析
            print("\n🧠 记忆化vs推理分析:")
            
            significant_drops = []
            for perturb_type, acc in accuracies.items():
                if perturb_type != "clean" and baseline_acc > 0:
                    drop = (baseline_acc - acc) / baseline_acc
                    if drop > 0.2:  # 显著下降
                        significant_drops.append((perturb_type, drop))
            
            if significant_drops:
                print("❗ 发现显著性能下降，可能表明记忆化依赖:")
                for perturb_type, drop in significant_drops:
                    print(f"  - {perturb_type}: 下降 {drop:.1%}")
            else:
                print("✅ 性能相对稳定，模型可能具有一定推理能力")
        
        else:
            print("⚠️  缺少baseline结果，无法进行对比分析")

def run_kk_evaluation(model_key: str = "qwen-0.5b"):
    """运行Knights and Knaves评估"""
    print("🚀 启动Knights and Knaves逻辑推理能力评估")
    print("="*60)
    
    evaluator = LocalKKEvaluator(model_key)
    
    try:
        # 运行扰动对比实验
        results = evaluator.compare_perturbations(
            base_subject="people2_num100",
            perturbation_types=["clean", "perturbed_leaf", "flip_role", "uncommon_name"],
            limit=15  # 使用较少样本进行演示
        )
        
        print("\n" + "="*60)
        print("🎉 Knights and Knaves评估完成！")
        
    except Exception as e:
        print(f"❌ 评估失败: {e}")
    
    finally:
        evaluator.cleanup_model()

if __name__ == "__main__":
    run_kk_evaluation() 