#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Jin et al. (2024) 记忆推理分离 - 本地模型版本

使用本地LLM模型进行记忆和推理步骤的分离评估
"""

import sys
import os
sys.path.append('../../')

from local_llm_interface import load_model, SUPPORTED_MODELS
import json
import time
import re
from typing import Dict, List, Tuple, Optional
import random

class StepTypeClassifier:
    """步骤类型分类器（简化版本）"""
    
    def __init__(self):
        self.memory_keywords = [
            'know', 'remember', 'fact', 'information', 'data', 'history', 
            'definition', 'meaning', 'concept', 'encyclopedia', 'knowledge',
            'learned', 'studied', 'taught', 'according to', 'wikipedia',
            'commonly known', 'well-known', 'established', 'traditional'
        ]
        
        self.reasoning_keywords = [
            'therefore', 'thus', 'because', 'since', 'hence', 'consequently',
            'implies', 'suggests', 'indicates', 'shows', 'proves', 'demonstrates',
            'analyzing', 'considering', 'examining', 'comparing', 'evaluating',
            'if', 'then', 'given', 'assume', 'suppose', 'logic', 'reasoning'
        ]
    
    def classify_step(self, step_text: str) -> str:
        """分类单个步骤为memory或reason"""
        step_lower = step_text.lower()
        
        memory_score = sum(1 for kw in self.memory_keywords if kw in step_lower)
        reasoning_score = sum(1 for kw in self.reasoning_keywords if kw in step_lower)
        
        if memory_score > reasoning_score:
            return "memory"
        elif reasoning_score > memory_score:
            return "reason"
        else:
            # 默认为推理
            return "reason"
    
    def analyze_response(self, response: str) -> Dict:
        """分析回答中的步骤分布"""
        # 将回答分割为步骤
        sentences = [s.strip() for s in response.split('.') if s.strip()]
        
        if not sentences:
            return {"memory_steps": 0, "reason_steps": 0, "total_steps": 0, "step_details": []}
        
        step_details = []
        memory_count = 0
        reason_count = 0
        
        for i, sentence in enumerate(sentences):
            if len(sentence) > 10:  # 过滤过短的句子
                step_type = self.classify_step(sentence)
                step_details.append({
                    "step_id": i,
                    "text": sentence,
                    "type": step_type
                })
                
                if step_type == "memory":
                    memory_count += 1
                else:
                    reason_count += 1
        
        total_steps = memory_count + reason_count
        
        return {
            "memory_steps": memory_count,
            "reason_steps": reason_count,
            "total_steps": total_steps,
            "memory_ratio": memory_count / total_steps if total_steps > 0 else 0,
            "reason_ratio": reason_count / total_steps if total_steps > 0 else 0,
            "step_details": step_details
        }

class LocalJinEvaluator:
    """Jin等人方法的本地模型评估器"""
    
    def __init__(self, model_key: str = "qwen-0.5b"):
        """初始化评估器"""
        self.model_key = model_key
        self.llm = None
        self.classifier = StepTypeClassifier()
        
    def load_model(self):
        """加载模型"""
        if self.llm is None:
            print(f"🔥 Loading model: {self.model_key}")
            self.llm = load_model(self.model_key)
    
    def cleanup_model(self):
        """清理模型"""
        if self.llm is not None:
            self.llm.cleanup()
            self.llm = None
    
    def create_test_questions(self) -> List[Dict]:
        """创建测试问题集合"""
        questions = [
            # 记忆密集型问题
            {
                "question": "What is the capital of France and when was it founded?",
                "type": "memory_intensive",
                "expected_memory_ratio": 0.7
            },
            {
                "question": "Who wrote Romeo and Juliet and what year was it published?",
                "type": "memory_intensive", 
                "expected_memory_ratio": 0.8
            },
            {
                "question": "What is the chemical formula for water and what are its properties?",
                "type": "memory_intensive",
                "expected_memory_ratio": 0.6
            },
            
            # 推理密集型问题
            {
                "question": "If all birds can fly and penguins are birds, why can't penguins fly?",
                "type": "reasoning_intensive",
                "expected_memory_ratio": 0.2
            },
            {
                "question": "A train leaves station A at 10 AM traveling at 60 mph. Another train leaves station B at 11 AM traveling at 80 mph toward station A. If the stations are 280 miles apart, when will they meet?",
                "type": "reasoning_intensive",
                "expected_memory_ratio": 0.1
            },
            {
                "question": "If you have 3 apples and give away 2, then buy 5 more, how many apples do you have? Explain your reasoning.",
                "type": "reasoning_intensive",
                "expected_memory_ratio": 0.1
            },
            
            # 混合型问题
            {
                "question": "Explain why water boils at 100°C at sea level and how altitude affects this process.",
                "type": "mixed",
                "expected_memory_ratio": 0.5
            },
            {
                "question": "Compare the causes of World War I and World War II and analyze their similarities.",
                "type": "mixed",
                "expected_memory_ratio": 0.4
            }
        ]
        
        return questions
    
    def evaluate_question(self, question_data: Dict) -> Dict:
        """评估单个问题"""
        question = question_data["question"]
        
        # 构造提示
        prompt = f"Please answer the following question step by step, providing detailed reasoning:\n\nQuestion: {question}\n\nAnswer:"
        
        try:
            # 生成回答
            response = self.llm.query(prompt, max_new_tokens=300, temperature=0.3)
            
            # 分析步骤类型
            analysis = self.classifier.analyze_response(response)
            
            # 计算与预期的差异
            expected_memory_ratio = question_data.get("expected_memory_ratio", 0.5)
            actual_memory_ratio = analysis["memory_ratio"]
            ratio_difference = abs(expected_memory_ratio - actual_memory_ratio)
            
            result = {
                "question": question,
                "question_type": question_data["type"],
                "response": response,
                "expected_memory_ratio": expected_memory_ratio,
                "actual_memory_ratio": actual_memory_ratio,
                "ratio_difference": ratio_difference,
                "step_analysis": analysis,
                "alignment_score": 1 - ratio_difference  # 对齐度得分
            }
            
            return result
            
        except Exception as e:
            return {
                "question": question,
                "question_type": question_data["type"],
                "response": f"ERROR: {str(e)}",
                "expected_memory_ratio": question_data.get("expected_memory_ratio", 0.5),
                "actual_memory_ratio": 0.0,
                "ratio_difference": 1.0,
                "step_analysis": {"error": str(e)},
                "alignment_score": 0.0
            }
    
    def run_comprehensive_evaluation(self) -> Dict:
        """运行全面评估"""
        print("🎯 记忆vs推理分离能力评估实验")
        print("="*60)
        print("目标：分析模型在不同类型问题上的记忆/推理步骤分布")
        print()
        
        # 加载模型
        self.load_model()
        
        # 获取测试问题
        questions = self.create_test_questions()
        
        results = []
        start_time = time.time()
        
        for i, question_data in enumerate(questions):
            print(f"\n📋 评估问题 {i+1}/{len(questions)}: {question_data['type']}")
            
            result = self.evaluate_question(question_data)
            results.append(result)
            
            # 显示进度
            analysis = result["step_analysis"]
            if "error" not in analysis:
                print(f"  记忆步骤: {analysis['memory_steps']}")
                print(f"  推理步骤: {analysis['reason_steps']}")
                print(f"  记忆比例: {analysis['memory_ratio']:.2%}")
                print(f"  对齐度: {result['alignment_score']:.2%}")
        
        eval_time = time.time() - start_time
        
        # 分析结果
        analysis_summary = self.analyze_results(results)
        
        final_result = {
            "model": self.model_key,
            "evaluation_time": eval_time,
            "total_questions": len(questions),
            "detailed_results": results,
            "summary_analysis": analysis_summary
        }
        
        # 保存结果
        save_path = f"jin_memory_reasoning_results_{self.model_key}.json"
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(final_result, f, ensure_ascii=False, indent=2)
        print(f"\n💾 结果已保存到: {save_path}")
        
        return final_result
    
    def analyze_results(self, results: List[Dict]) -> Dict:
        """分析评估结果"""
        print("\n📈 记忆vs推理分离分析")
        print("-" * 40)
        
        # 按问题类型分组
        type_results = {}
        for result in results:
            qtype = result["question_type"]
            if qtype not in type_results:
                type_results[qtype] = []
            type_results[qtype].append(result)
        
        # 分析每种类型
        type_analysis = {}
        for qtype, type_results_list in type_results.items():
            valid_results = [r for r in type_results_list if "error" not in r["step_analysis"]]
            
            if valid_results:
                avg_memory_ratio = sum(r["actual_memory_ratio"] for r in valid_results) / len(valid_results)
                avg_alignment = sum(r["alignment_score"] for r in valid_results) / len(valid_results)
                
                type_analysis[qtype] = {
                    "question_count": len(valid_results),
                    "avg_memory_ratio": avg_memory_ratio,
                    "avg_alignment_score": avg_alignment
                }
                
                print(f"{qtype}:")
                print(f"  平均记忆比例: {avg_memory_ratio:.2%}")
                print(f"  平均对齐度: {avg_alignment:.2%}")
        
        # 整体分析
        all_valid = [r for r in results if "error" not in r["step_analysis"]]
        if all_valid:
            overall_memory_ratio = sum(r["actual_memory_ratio"] for r in all_valid) / len(all_valid)
            overall_alignment = sum(r["alignment_score"] for r in all_valid) / len(all_valid)
            
            print(f"\n🧠 整体分析:")
            print(f"  整体记忆比例: {overall_memory_ratio:.2%}")
            print(f"  整体对齐度: {overall_alignment:.2%}")
            
            # 判断模型特性
            if overall_memory_ratio > 0.6:
                print("💡 结论: 模型倾向于依赖记忆化")
            elif overall_memory_ratio < 0.4:
                print("💡 结论: 模型倾向于依赖推理")
            else:
                print("💡 结论: 模型在记忆和推理之间相对平衡")
            
            if overall_alignment > 0.7:
                print("✅ 模型能较好地适应不同类型问题的要求")
            else:
                print("⚠️  模型在适应不同类型问题方面有改进空间")
        
        return {
            "type_analysis": type_analysis,
            "overall_memory_ratio": overall_memory_ratio if all_valid else 0,
            "overall_alignment": overall_alignment if all_valid else 0,
            "total_valid_questions": len(all_valid)
        }

def run_jin_evaluation(model_key: str = "qwen-0.5b"):
    """运行Jin等人的记忆推理分离评估"""
    print("🚀 启动记忆与推理分离能力评估")
    print("="*60)
    
    evaluator = LocalJinEvaluator(model_key)
    
    try:
        results = evaluator.run_comprehensive_evaluation()
        
        print("\n" + "="*60)
        print("🎉 记忆推理分离评估完成！")
        
        return results
        
    except Exception as e:
        print(f"❌ 评估失败: {e}")
        return None
    
    finally:
        evaluator.cleanup_model()

if __name__ == "__main__":
    run_jin_evaluation() 