#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Knights and Knaves 记忆化vs推理演示脚本

这个脚本展示了Xie et al. (2024)论文中Knights and Knaves逻辑谜题
用于测试大语言模型记忆化vs推理能力的方法。
"""

import json
import random
from utils import load_jsonl

def load_and_display_samples():
    """加载并展示不同类型的Knights and Knaves样本"""
    
    print("=" * 80)
    print("Knights and Knaves 记忆化vs推理测试演示")
    print("=" * 80)
    print()
    
    # 1. 显示clean版本的示例
    print("1. 原始(Clean)版本示例:")
    print("-" * 40)
    clean_data = load_jsonl("data/test/clean/people2_num100.jsonl")
    sample = clean_data[0]
    
    print(f"问题: {sample['quiz']}")
    print(f"正确答案: {sample['solution_text_format']}")
    print(f"思维链推理: {sample['cot_head']}")
    for i, step in enumerate(sample['cot_repeat_steps'][:3], 1):
        print(f"  步骤{i}: {step}")
    print(f"  ... (共{len(sample['cot_repeat_steps'])}步)")
    print(f"结论: {sample['cot_foot']}")
    print()
    
    # 2. 显示扰动版本的示例
    print("2. 叶节点扰动(Perturbed Leaf)版本示例:")
    print("-" * 40)
    perturb_data = load_jsonl("data/test/perturbed_leaf/people2_num100.jsonl")
    sample = perturb_data[0]
    
    print(f"问题: {sample['quiz']}")
    print(f"正确答案: {sample['solution_text_format']}")
    print("注意: 这个版本的逻辑结构被微调，用于测试模型是否真的在进行推理")
    print()
    
    # 3. 显示语言扰动版本的示例
    print("3. 角色翻转(Flip Role)版本示例:")
    print("-" * 40)
    flip_data = load_jsonl("data/test/flip_role/people2_num100.jsonl")
    sample = flip_data[0]
    
    print(f"问题: {sample['quiz']}")
    print(f"正确答案: {sample['solution_text_format']}")
    print("注意: 这个版本翻转了knights和knaves的定义，测试模型对表面形式的依赖")
    print()
    
    return clean_data, perturb_data, flip_data

def analyze_problem_complexity():
    """分析不同复杂度的问题"""
    print("4. 问题复杂度分析:")
    print("-" * 40)
    
    # 加载不同人数的数据
    complexities = [
        ("2人问题", "data/test/clean/people2_num100.jsonl"),
        ("3人问题", "data/test/clean/people3_num100.jsonl"),
        ("4人问题", "data/test/clean/people4_num100.jsonl")
    ]
    
    for name, path in complexities:
        try:
            data = load_jsonl(path)
            sample = data[0]
            print(f"{name}:")
            print(f"  涉及人数: {len(sample['names'])}")
            print(f"  推理步骤数: {len(sample['cot_repeat_steps'])}")
            print(f"  问题长度: {len(sample['quiz'])} 字符")
            print()
        except FileNotFoundError:
            print(f"{name}: 数据文件未找到")
            continue

def demonstrate_perturbation_types():
    """演示不同的扰动类型"""
    print("5. 扰动类型对比:")
    print("-" * 40)
    
    perturbation_types = [
        ("clean", "原始版本"),
        ("perturbed_statement", "语句扰动"),
        ("perturbed_leaf", "叶节点扰动"),
        ("random_pair", "随机配对"),
        ("flip_role", "角色翻转"),
        ("uncommon_name", "罕见姓名"),
        ("reorder_statement", "语句重排")
    ]
    
    base_path = "data/test/{}/people2_num100.jsonl"
    
    for perturb_type, description in perturbation_types:
        try:
            data = load_jsonl(base_path.format(perturb_type))
            sample = data[0]
            print(f"{description} ({perturb_type}):")
            print(f"  问题长度: {len(sample['quiz'])} 字符")
            print(f"  使用的名字: {', '.join(sample['names'])}")
            if perturb_type == "flip_role":
                print(f"  特殊说明: Knights和Knaves的定义可能被翻转")
            print()
        except FileNotFoundError:
            print(f"{description}: 数据文件未找到")
            continue

def explain_evaluation_methodology():
    """解释评估方法论"""
    print("6. 评估方法论:")
    print("-" * 40)
    print("该项目通过以下方式测试模型的记忆化vs推理能力：")
    print()
    print("a) 基准测试：在原始clean数据上测试模型性能")
    print("b) 扰动测试：在各种扰动版本上测试模型性能")
    print("c) 性能对比：")
    print("   - 如果模型主要依赖记忆化，扰动版本性能会显著下降")
    print("   - 如果模型真正在推理，扰动版本性能应该保持稳定")
    print()
    print("d) 关键指标：")
    print("   - Clean准确率：在原始数据上的表现")
    print("   - 扰动准确率：在扰动数据上的表现")
    print("   - 记忆化指标：两者之间的差异")
    print()

def demonstrate_sample_evaluation():
    """演示样本评估过程"""
    print("7. 样本评估演示:")
    print("-" * 40)
    
    # 加载一个样本
    clean_data = load_jsonl("data/test/clean/people2_num100.jsonl")
    sample = clean_data[0]
    
    print("给定问题:")
    print(f'"{sample["quiz"]}"')
    print()
    
    print("正确答案格式:")
    print(f'"{sample["solution_text_format"]}"')
    print()
    
    print("评估过程:")
    print("1. 模型生成回答")
    print("2. 解析模型回答中的人物身份判断")
    print("3. 与正确答案对比")
    print("4. 计算准确率")
    print()
    
    print("推理链评估:")
    print("- 检查模型是否使用了正确的逻辑推理步骤")
    print("- 分析推理过程是否与预期的思维链一致")
    print()

def main():
    """主函数"""
    try:
        # 加载和展示样本
        clean_data, perturb_data, flip_data = load_and_display_samples()
        
        # 分析问题复杂度
        analyze_problem_complexity()
        
        # 演示扰动类型
        demonstrate_perturbation_types()
        
        # 解释评估方法
        explain_evaluation_methodology()
        
        # 演示评估过程
        demonstrate_sample_evaluation()
        
        print("=" * 80)
        print("演示完成！")
        print("=" * 80)
        print()
        print("下一步：")
        print("1. 使用eval_kk.py脚本在实际LLM上运行评估")
        print("2. 比较不同扰动类型的性能差异")
        print("3. 分析模型的记忆化vs推理能力")
        print()
        print("示例命令:")
        print("python eval_kk.py --model gpt-3.5-turbo --ntrain 0 --problem_type clean")
        print("python eval_kk.py --model gpt-3.5-turbo --ntrain 0 --problem_type perturbed_leaf")
        
    except Exception as e:
        print(f"演示过程中出现错误: {e}")
        print("请确保数据文件已生成（运行data_prep/data_gen_kk.py）")

if __name__ == "__main__":
    main() 