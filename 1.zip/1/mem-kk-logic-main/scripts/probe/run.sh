nppl_eval=3
adapter_path=""
base_model_path=""

python probe.py --base_model_path $base_model_path --adapter_path $adapter_path --nppl_eval $nppl_eval 
