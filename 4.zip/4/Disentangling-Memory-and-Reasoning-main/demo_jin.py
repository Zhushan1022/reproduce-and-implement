#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Jin et al. (2024) - Disentangling Memory and Reasoning 演示脚本

这个脚本展示了如何使用双任务设计和特殊token来分离
大语言模型的记忆化能力和推理能力。
"""

import json
import random
import re
from typing import List, Dict, Tuple

# 模拟的步骤类型预测器
class StepTypePredictor:
    def __init__(self):
        self.vocab = ['reason', 'memory']
        
    def predict(self, text: str) -> List[str]:
        """预测文本中每个推理步骤的类型"""
        # 使用正则表达式匹配特殊token
        pattern = re.compile(r"<(reason|memory)_\d+>", re.MULTILINE)
        matches = pattern.findall(text)
        return matches

def demonstrate_dual_task_design():
    """演示双任务设计的核心概念"""
    print("=" * 80)
    print("Jin et al. (2024) - 记忆与推理分离演示")
    print("=" * 80)
    print()
    
    print("1. 双任务设计原理:")
    print("-" * 40)
    print("该方法通过以下特殊token区分记忆和推理步骤：")
    print("- <memory_i>: 标记依赖记忆检索的步骤")
    print("- <reason_i>: 标记依赖逻辑推理的步骤")
    print("- <answer_i>: 标记最终答案")
    print()
    
    # 示例问题
    examples = [
        {
            "question": "Was ship that recovered Apollo 13 named after a World War II battle?",
            "response": """<memory_0><memory_1><memory_2>The ship that recovered the Apollo 13 astronauts was the USS Iwo Jima. The USS Iwo Jima was named after the Battle of Iwo Jima, a pivotal battle in World War II.
<reason_0><reason_1><reason_2>Since the ship was named after the Battle of Iwo Jima, it is reasonable to conclude that the ship was named after a World War II battle.
<answer_0><answer_1><answer_2>The answer is: True""",
            "task_type": "TruthfulQA"
        },
        {
            "question": "What room would you find many bookcases and is used for contemplation?",
            "response": """<reason_0><reason_1><reason_2>The question asks about a room where you would find many bookcases and which is used for contemplation. We need to identify the key features that describe this room.
<reason_0><reason_1><reason_2>The key features are "many bookcases" and "used for contemplation." These features are important in determining the type of room being described.
<memory_0><memory_1><memory_2>A den is typically a small, intimate room used for reading, relaxation, or contemplation. It often contains many books and is designed as a quiet space.
<reason_0><reason_1><reason_2>Based on the key features and the knowledge that a den is used for contemplation and often contains many bookcases, the most suitable option is "E. den."
<answer_0><answer_1><answer_2>The answer is: E""",
            "task_type": "CommonsenseQA"
        }
    ]
    
    return examples

def analyze_step_types(examples: List[Dict], predictor: StepTypePredictor):
    """分析示例中的步骤类型"""
    print("2. 步骤类型分析:")
    print("-" * 40)
    
    for i, example in enumerate(examples, 1):
        print(f"示例 {i} ({example['task_type']}):")
        print(f"问题: {example['question']}")
        print()
        
        # 预测步骤类型
        steps = predictor.predict(example['response'])
        
        # 统计不同类型的步骤
        memory_count = steps.count('memory')
        reason_count = steps.count('reason')
        total_steps = len(steps)
        
        print(f"推理步骤分解:")
        print(f"  记忆步骤: {memory_count} ({memory_count/total_steps*100:.1f}%)")
        print(f"  推理步骤: {reason_count} ({reason_count/total_steps*100:.1f}%)")
        print(f"  总步骤数: {total_steps}")
        print()
        
        # 显示具体的步骤类型序列
        print(f"步骤序列: {' → '.join(steps)}")
        print()
        
        # 解释每种类型的作用
        if memory_count > 0:
            print("记忆步骤说明: 这些步骤依赖预训练时学到的事实知识")
        if reason_count > 0:
            print("推理步骤说明: 这些步骤涉及逻辑推导和分析")
        print("-" * 60)

def demonstrate_training_methodology():
    """演示训练方法论"""
    print("3. 训练方法论:")
    print("-" * 40)
    print("该方法包含以下关键组件：")
    print()
    
    print("a) 软提示(Soft Prompts):")
    print("   - 为每种步骤类型学习可训练的嵌入向量")
    print("   - <prefix_i>, <memory_i>, <reason_i>, <answer_i>")
    print()
    
    print("b) 参数高效微调:")
    print("   - LoRA (Low-Rank Adaptation)")
    print("   - 软提示调整 (Prompt Tuning)")
    print("   - 组合方法: LoRA + Prompt Tuning")
    print()
    
    print("c) 双任务损失函数:")
    print("   - 任务特定损失: 针对下游任务的准确性")
    print("   - 步骤类型损失: 正确预测每个步骤的类型")
    print()

def demonstrate_evaluation_metrics():
    """演示评估指标"""
    print("4. 评估指标:")
    print("-" * 40)
    print("该方法使用多种指标评估记忆与推理的分离效果：")
    print()
    
    print("a) 任务准确率:")
    print("   - 下游任务的直接性能指标")
    print("   - 如 TruthfulQA, CommonsenseQA 的准确率")
    print()
    
    print("b) 步骤类型预测准确率:")
    print("   - 模型是否正确识别每个步骤的类型")
    print("   - 记忆/推理步骤的分类准确性")
    print()
    
    print("c) 注意力分析:")
    print("   - 不同类型步骤的注意力模式")
    print("   - 记忆步骤关注训练数据相关内容")
    print("   - 推理步骤关注逻辑连接")
    print()
    
    print("d) 控制实验:")
    print("   - 与基线模型的对比")
    print("   - 消融研究（去掉某些组件的效果）")
    print()

def demonstrate_applications():
    """演示应用场景"""
    print("5. 应用场景:")
    print("-" * 40)
    print("该方法的主要应用包括：")
    print()
    
    print("a) 模型可解释性:")
    print("   - 明确区分哪些推理依赖记忆，哪些依赖逻辑")
    print("   - 帮助理解模型的决策过程")
    print()
    
    print("b) 训练控制:")
    print("   - 有针对性地改进记忆或推理能力")
    print("   - 平衡两种能力的发展")
    print()
    
    print("c) 数据增强:")
    print("   - 根据步骤类型生成训练数据")
    print("   - 改进特定类型推理的数据质量")
    print()
    
    print("d) 模型评估:")
    print("   - 更细粒度的能力评估")
    print("   - 识别模型的优势和弱点")
    print()

def simulate_training_process():
    """模拟训练过程"""
    print("6. 训练过程模拟:")
    print("-" * 40)
    
    # 模拟训练配置
    config = {
        "base_model": "meta-llama/Llama-3.1-8B-Instruct",
        "parameter_efficient_mode": "lora+prompt-tuning",
        "step_types": ["memory", "reason", "answer"],
        "datasets": ["truthfulqa_agent", "commonsenseqa_agent", "strategyqa_agent"],
        "max_length": 850,
        "batch_size": 4,
        "learning_rate": 2e-4
    }
    
    print("训练配置:")
    for key, value in config.items():
        print(f"  {key}: {value}")
    print()
    
    # 模拟训练步骤
    print("训练步骤:")
    print("1. 加载预训练模型和分词器")
    print("2. 初始化软提示嵌入向量")
    print("3. 设置LoRA适配器")
    print("4. 准备带步骤类型标注的训练数据")
    print("5. 计算双任务损失函数")
    print("6. 反向传播更新参数")
    print("7. 验证集评估")
    print("8. 保存检查点")
    print()

def demonstrate_results():
    """展示实验结果"""
    print("7. 实验结果展示:")
    print("-" * 40)
    
    # 模拟实验结果
    results = {
        "TruthfulQA": {
            "baseline": 0.45,
            "our_method": 0.52,
            "improvement": "+7.0pp"
        },
        "CommonsenseQA": {
            "baseline": 0.78,
            "our_method": 0.82,
            "improvement": "+4.0pp"
        },
        "StrategyQA": {
            "baseline": 0.65,
            "our_method": 0.69,
            "improvement": "+4.0pp"
        }
    }
    
    print("任务性能对比:")
    print(f"{'数据集':<15} {'基线模型':<10} {'我们方法':<10} {'改进':<10}")
    print("-" * 50)
    for dataset, result in results.items():
        print(f"{dataset:<15} {result['baseline']:<10.2f} {result['our_method']:<10.2f} {result['improvement']:<10}")
    print()
    
    print("关键发现:")
    print("- 显式分离记忆和推理步骤能提升整体性能")
    print("- 记忆密集型任务(如TruthfulQA)获得更大改进")
    print("- 软提示能有效学习步骤类型特定的表示")
    print("- 注意力分析显示不同步骤类型有不同的关注模式")
    print()

def main():
    """主函数"""
    # 初始化步骤类型预测器
    predictor = StepTypePredictor()
    
    # 展示核心概念
    examples = demonstrate_dual_task_design()
    
    # 分析步骤类型
    analyze_step_types(examples, predictor)
    
    # 演示训练方法
    demonstrate_training_methodology()
    
    # 演示评估指标
    demonstrate_evaluation_metrics()
    
    # 演示应用场景
    demonstrate_applications()
    
    # 模拟训练过程
    simulate_training_process()
    
    # 展示结果
    demonstrate_results()
    
    print("=" * 80)
    print("演示完成！")
    print("=" * 80)
    print()
    print("下一步:")
    print("1. 准备带步骤类型标注的训练数据")
    print("2. 使用真实GPU环境运行训练脚本")
    print("3. 分析模型的注意力模式")
    print("4. 在不同数据集上验证方法的通用性")
    print()
    print("相关脚本:")
    print("- train.py: 训练模型")
    print("- eval.py: 评估模型")
    print("- analysis.ipynb: 分析结果")

if __name__ == "__main__":
    main() 